-- phpMyAdmin SQL Dump
-- version 3.1.5
-- http://www.phpmyadmin.net
--
-- Serveur: arnould.f.sql.free.fr
-- Généré le : Mar 26 Mars 2013 à 10:39
-- Version du serveur: 5.0.83
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `arnould_f`
--

-- --------------------------------------------------------

--
-- Structure de la table `lapin_Ami`
--

CREATE TABLE IF NOT EXISTS `lapin_Ami` (
  `idProprio` varchar(30) collate latin1_general_ci NOT NULL default '',
  `idAmi` varchar(30) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`idProprio`,`idAmi`),
  KEY `FKAmi2` (`idAmi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_appartientA`
--

CREATE TABLE IF NOT EXISTS `lapin_appartientA` (
  `id_disc` int(11) NOT NULL,
  `id_profil` int(11) NOT NULL,
  PRIMARY KEY  (`id_disc`,`id_profil`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_aSupprimer`
--

CREATE TABLE IF NOT EXISTS `lapin_aSupprimer` (
  `id_profil` int(11) NOT NULL,
  `id_mess` int(11) NOT NULL,
  PRIMARY KEY  (`id_profil`,`id_mess`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_Consultation`
--

CREATE TABLE IF NOT EXISTS `lapin_Consultation` (
  `id_profil` int(11) NOT NULL,
  `derniere` datetime NOT NULL,
  PRIMARY KEY  (`id_profil`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_Discussion`
--

CREATE TABLE IF NOT EXISTS `lapin_Discussion` (
  `id_disc` int(11) NOT NULL auto_increment,
  `sujet` varchar(20) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `intitule` varchar(64) NOT NULL default '',
  `auteur` int(11) NOT NULL,
  `dest` int(11) default NULL,
  PRIMARY KEY  (`id_disc`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_lapin`
--

CREATE TABLE IF NOT EXISTS `lapin_lapin` (
  `id_lapin` int(11) NOT NULL auto_increment,
  `nomlap` varchar(30) NOT NULL COMMENT 'nom du lapin',
  `agelap` date NOT NULL COMMENT 'age',
  `race` varchar(15) NOT NULL COMMENT 'race',
  `sexe` varchar(1) NOT NULL COMMENT 'sexe',
  `couleur` varchar(10) NOT NULL COMMENT 'couleur',
  `description` varchar(200) NOT NULL COMMENT 'description',
  `centreInteret` varchar(100) NOT NULL COMMENT 'interet',
  `photo` varchar(30) NOT NULL COMMENT 'photo',
  `identifiant` varchar(30) NOT NULL COMMENT 'identifiant du proprietaire',
  `id_profil` int(11) NOT NULL COMMENT 'identifiant du proprietaire',
  PRIMARY KEY  (`id_lapin`),
  KEY `identifiant` (`identifiant`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_Message`
--

CREATE TABLE IF NOT EXISTS `lapin_Message` (
  `id_mess` int(11) NOT NULL auto_increment,
  `titre` varchar(64) NOT NULL,
  `texte` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `id_disc` int(11) NOT NULL,
  `id_lapin` int(11) NOT NULL,
  PRIMARY KEY  (`id_mess`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_proprietaire`
--

CREATE TABLE IF NOT EXISTS `lapin_proprietaire` (
  `id_profil` int(11) NOT NULL auto_increment,
  `identifiant` varchar(30) NOT NULL COMMENT 'nom d''utilisateur',
  `nom` varchar(30) NOT NULL COMMENT 'nom',
  `prenom` varchar(30) NOT NULL COMMENT 'prenom',
  `code_postal` int(5) NOT NULL COMMENT 'code postal',
  `region` varchar(30) default NULL COMMENT 'region',
  `mail` varchar(60) NOT NULL COMMENT 'mail',
  `passwd` varchar(40) NOT NULL COMMENT 'mot de passe',
  `date_dernier_signal` datetime default NULL COMMENT 'date dernier signal',
  `date_acces_session` datetime default NULL COMMENT 'variable de session representant la date',
  `trombine` varchar(30) default NULL COMMENT 'photo',
  PRIMARY KEY  (`identifiant`),
  UNIQUE KEY `id_profil` (`id_profil`),
  UNIQUE KEY `identifiant` (`identifiant`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_repondA`
--

CREATE TABLE IF NOT EXISTS `lapin_repondA` (
  `src` int(11) NOT NULL,
  `rep` int(11) NOT NULL,
  PRIMARY KEY  (`src`,`rep`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_tchat_conversation`
--

CREATE TABLE IF NOT EXISTS `lapin_tchat_conversation` (
  `id_conversation` int(11) NOT NULL auto_increment COMMENT 'numero de fil de conversation',
  `user1` varchar(20) NOT NULL COMMENT 'utilisateur 1',
  `session_1` datetime NOT NULL COMMENT 'date de la session (user1)',
  `user2` varchar(20) NOT NULL COMMENT 'utilisateur 2',
  `session_2` datetime NOT NULL COMMENT 'date de la session (user2)',
  PRIMARY KEY  (`id_conversation`),
  KEY `user1` (`user1`),
  KEY `user2` (`user2`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `lapin_tchat_message`
--

CREATE TABLE IF NOT EXISTS `lapin_tchat_message` (
  `id_message` int(11) NOT NULL auto_increment COMMENT 'numero id du message',
  `conversation` int(11) NOT NULL COMMENT 'numero de la conversation courante',
  `expediteur` varchar(20) NOT NULL COMMENT 'id exped',
  `destinataire` varchar(20) NOT NULL COMMENT 'id dest',
  `texte` text COMMENT 'contenu',
  `date` datetime NOT NULL COMMENT 'date de l''envoi',
  PRIMARY KEY  (`id_message`),
  KEY `conversation` (`conversation`),
  KEY `expediteur` (`expediteur`),
  KEY `destinataire` (`destinataire`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
