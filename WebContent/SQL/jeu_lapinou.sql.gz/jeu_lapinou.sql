-- phpMyAdmin SQL Dump
-- version 3.1.5
-- http://www.phpmyadmin.net
--
-- Serveur: arnould.f.sql.free.fr
-- Généré le : Mar 26 Mars 2013 à 10:42
-- Version du serveur: 5.0.83
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `arnould_f`
--

--
-- Contenu de la table `lapin_Ami`
--

INSERT INTO `lapin_Ami` (`idProprio`, `idAmi`) VALUES
('Jojo', 'dominique'),
('Jojo', 'Dudule'),
('Jojo', 'Julie'),
('Julie', 'Jojo'),
('root', 'Roger2');

--
-- Contenu de la table `lapin_appartientA`
--


--
-- Contenu de la table `lapin_aSupprimer`
--


--
-- Contenu de la table `lapin_Consultation`
--

INSERT INTO `lapin_Consultation` (`id_profil`, `derniere`) VALUES
(3, '2013-02-23 18:36:49'),
(1, '2013-03-25 14:58:38'),
(5, '2013-03-20 11:43:23'),
(26, '2013-03-25 14:58:38'),
(30, '2013-03-25 20:53:19');

--
-- Contenu de la table `lapin_Discussion`
--

INSERT INTO `lapin_Discussion` (`id_disc`, `sujet`, `date`, `intitule`, `auteur`, `dest`) VALUES
(1, 'Jazz Jack', '2013-02-09 18:43:17', 'titre', 3, 1),
(2, 'Jazz Jack', '2013-02-09 20:48:17', 'intitule', 3, 1),
(3, 'Jazz Jack', '2013-02-09 20:48:34', 'test', 3, 5),
(4, 'Jazz Jack', '2013-02-09 20:48:53', 'bis repetita', 3, 1),
(5, 'nouveautÃ©', '2013-02-28 18:27:46', 'lancement', 2, 8),
(6, 'nouveautÃ©', '2013-02-28 18:29:39', 'lancement', 2, 8),
(7, '15', '2013-03-20 11:42:55', 'discuter', 4, 15),
(8, '12', '2013-03-23 11:04:53', 'bonjour', 9, 12),
(9, '13', '2013-03-25 13:20:20', 'Salut Roby', 12, 13),
(10, '13', '2013-03-25 14:01:52', 'Rencontre', 12, 13),
(11, '11', '2013-03-25 14:51:49', 'coucou', 1, 11),
(12, '10', '2013-03-25 14:53:18', 'lkjm', 4, 10),
(13, '7', '2013-03-25 14:53:45', 'test', 4, 7);

--
-- Contenu de la table `lapin_lapin`
--

INSERT INTO `lapin_lapin` (`id_lapin`, `nomlap`, `agelap`, `race`, `sexe`, `couleur`, `description`, `centreInteret`, `photo`, `identifiant`, `id_profil`) VALUES
(4, 'Buck', '2012-12-05', 'petite', 0, 'unicolore', 'bcvbcvb', 'gdfgd', 'root1364219006.jpeg', 'root', 1),
(5, 'Bux', '0000-00-00', '', 0, '', '', '', '', 'Jeannot', 2),
(2, 'Civet', '0000-00-00', '', 0, '', '', '', '', 'root', 1),
(1, 'Jazz Jack', '0000-00-00', '', 0, '', '', '', '', 'root', 1),
(3, 'Jeannot', '0000-00-00', '', 0, '', '', '', '', 'root', 1),
(6, 'Panpan', '0000-00-00', '', 0, '', '', '', '', 'Jazz Jack', 3),
(7, 'Roger', '0000-00-00', '', 0, '', '', '', '', 'Roger', 4),
(8, 'Serpolet', '0000-00-00', '', 0, '', '', '', '', 'Roger', 4),
(9, 'joe', '0000-00-00', 'belier', 0, 'mosaique', '', 'carottes', '', 'dominique', 27),
(10, 'toto', '0000-00-00', 'rustique', 0, 'mosaique', 'dskhflskdhfncv,;xcb', 'Bouffer', 'Cyril21363698021.jpg', 'Cyril2', 28),
(11, 'zerzer', '0000-00-00', 'mutante', 0, 'tachete', '', '', 'Cyril21363699781.jpeg', 'Cyril2', 28),
(12, 'joj', '0000-00-00', 'naine', 0, 'panache', 'aime les câlins et manger des carottes', 'dormir et ...', 'Jojo1363700882.jpg', 'Jojo', 30),
(13, 'robert', '0000-00-00', 'naine', 0, 'tachete', 'Super motivé pour des rencontres', 'la bouffe', 'Julie1363700899.jpg', 'Julie', 26),
(14, 'azeaze', '0000-00-00', 'naine', 0, 'panache', '', '', '', 'oiuyoeirt', 29),
(15, 'serpolet', '0000-00-00', 'toons', 0, 'mosaique', 'petit mignon', 'la cuisine', '', 'Roger2', 5);

--
-- Contenu de la table `lapin_Message`
--

INSERT INTO `lapin_Message` (`id_mess`, `titre`, `texte`, `date`, `id_disc`, `id_lapin`) VALUES
(2, 'intitule', 'bla bla', '0000-00-00 00:00:00', 2, 3),
(3, 'test', 'Coucou !', '0000-00-00 00:00:00', 3, 3),
(4, 'bis repetita', 'remplissage', '0000-00-00 00:00:00', 4, 3),
(31, 'fghjh', 'fk lgl', '2013-02-18 02:00:43', 1, 1),
(32, 'hgjf', 'h lgh', '2013-02-18 02:01:12', 2, 1),
(33, 'fstgfgergser', 'fesrqse', '2013-02-20 12:06:39', 2, 1),
(34, 'sujet', 'fklerl', '2013-02-28 11:42:33', 2, 1),
(35, 'sujet', 'corps', '2013-02-28 11:43:25', 2, 1),
(36, 'fqfrf', 'gvsfg ss', '2013-02-28 12:10:43', 2, 1),
(37, 'test', 'rÃ©ouverture', '2013-02-28 15:36:45', 2, 1),
(38, 'bis', 'repetita', '2013-02-28 15:43:48', 4, 1),
(39, 'ter', 'minal', '2013-02-28 15:46:17', 4, 1),
(40, 'lancement', 'discussion', '2013-02-28 18:29:39', 6, 2),
(41, 'youpi !', 'Tralala.', '2013-03-12 10:48:46', 1, 1),
(42, 'RÃ©ponse', 'au message', '2013-03-12 11:21:01', 4, 1),
(43, 'test', 'nouveaux', '2013-03-12 11:36:22', 2, 1),
(44, 'test', 'nouveaux', '2013-03-12 11:39:07', 2, 1),
(45, 'essai', 'correction', '2013-03-12 12:00:22', 2, 1),
(46, 'réponse', 'test', '2013-03-12 12:31:07', 3, 3),
(47, 'bis', 'test', '2013-03-12 12:46:09', 3, 3),
(48, 'plus', 'ajout', '2013-03-12 16:52:59', 1, 1),
(49, 'encore', 'plus', '2013-03-12 16:56:00', 1, 1),
(50, 'ajout', 'test', '2013-03-19 14:56:23', 2, 1),
(51, 'test fermeture', 'ouvert ou fermé ?', '2013-03-20 11:39:05', 3, 3),
(52, 'discuter', 'blablabla', '2013-03-20 11:42:55', 7, 4),
(53, 'ok', 'pourquoi pas ?', '2013-03-20 11:43:40', 7, 15),
(54, 'bonjour', 'hello joe', '2013-03-23 11:04:53', 8, 9),
(55, 'Salut Roby', 'Comment vas tu ?\r\nJe suis un gentil lapin c', '2013-03-25 13:20:20', 9, 12),
(56, 'Salut Joe', 'ça gaze ? moi ça boom', '2013-03-25 13:56:46', 9, 13),
(57, 'Ouaich ma caille', 'Bien ou bien ?', '2013-03-25 14:00:50', 9, 12),
(58, 'Rencontre', '', '2013-03-25 14:01:52', 10, 12),
(59, 'Pourquoi pas ?', 'Je veux faire une rencontre. Il faudrait qu''on s''organise une petite soirée. Dis moi quand tu es libre ?', '2013-03-25 14:26:51', 10, 13),
(60, 'Re: Rencontre', 'Quand tu veux je suis OP... je vais faire un tour dans les champs et je reviens. Je nous prend des carottes ;)', '2013-03-25 14:28:33', 10, 12),
(61, 'Test...', 'Quand tu veux je suis OP... je vais faire un tour dans les champs et je reviens. Je nous prend des carottes ;)', '2013-03-25 14:31:42', 10, 12),
(62, 'ceci est un long titre de message pour voir jusque quand il y a ', 'et ici un looooooooooong message pour tenter le dépassement de capacité de la fenêtre de messagerie.$bla bla bla bla bla bla bla', '2013-03-25 14:32:24', 6, 2),
(63, 'Demande', 'Epouse moi !!!!!', '2013-03-25 14:35:13', 10, 12),
(64, 'Correction', 'J''aimerai te demander ta patte en mariage pour fonder un petit terrier. J''ai adoré notre soirée à courir dans les champs :D', '2013-03-25 14:36:12', 10, 12),
(65, 'coucou', 'toto', '2013-03-25 14:51:49', 11, 1),
(66, 'lkjm', 'fdhgd', '2013-03-25 14:53:18', 12, 4),
(67, 'test', 'blabla', '2013-03-25 14:53:45', 13, 4),
(68, 'Réponse', 'oui je le veux......', '2013-03-25 14:59:11', 10, 13),
(69, 'Bonjour', 'Bonjour :)', '2013-03-25 20:54:07', 8, 12),
(70, 'sermon', 'Vous êtes unis par les liens du mariage !!!', '2013-03-25 20:54:55', 10, 12);

--
-- Contenu de la table `lapin_proprietaire`
--

INSERT INTO `lapin_proprietaire` (`id_profil`, `identifiant`, `nom`, `prenom`, `code_postal`, `region`, `mail`, `passwd`, `date_dernier_signal`, `date_acces_session`, `trombine`) VALUES
(3, 'Jazz Jack', 'Jazz', 'Jack', 8000, NULL, '', '906f116eb480c6b710c2a0197b644afb372d34d3', NULL, NULL, NULL),
(2, 'Jeannot', 'Jeannot', '', 45000, NULL, '', '906f116eb480c6b710c2a0197b644afb372d34d3', NULL, NULL, NULL),
(4, 'Roger', 'Roger', '', 27000, NULL, '', '906f116eb480c6b710c2a0197b644afb372d34d3', NULL, NULL, NULL),
(1, 'root', 'Panpan', '', 0, NULL, '', '906f116eb480c6b710c2a0197b644afb372d34d3', '2013-03-12 12:29:32', '2013-03-11 18:22:55', NULL),
(5, 'Roger2', 'Roger', 'Roger', 45000, 'Centre', 'Roger@ici.fr', '7aa72604ee1e4b1dae362a91aab5cc35fea38237', NULL, NULL, NULL),
(6, 'test', 'teste', 'testete', 45560, 'Centre', 'cccc@ttt.gr', '3a5c58ae6f4c8f9db725d3c785f0dd99f9865821', NULL, NULL, NULL),
(7, 'dfgrtyrty', 'test', 'test', 12312, 'Midi-Pyrenees', 'aaaaer@lapi.net', 'bf1482156761b1970289a09eb5b3b8c21f7f8bea', NULL, NULL, NULL),
(8, 'frtrez', 'frezfrefer', 'fertrtr', 45000, 'Centre', 'Roger@ici.fr', '92563990bb6590decebb567b4e93f976eabb2aa1', NULL, NULL, NULL),
(9, 'Cyril', 'THURIER', 'Cyril', 45000, 'Centre', 'cyrilthurier@lapi.net', 'b199e9bc9e0ff6e8a4769b37e6a5910e7032ac6e', '2013-03-25 17:48:53', '2013-03-25 17:12:19', NULL),
(10, 'francine', 'france', 'francine', 12000, 'Midi-Pyrenees', 'free@gmail.com', 'ab2c8cf49dd93143a47b0e4cfff4a534be6e61f8', '2013-03-25 21:13:39', '2013-03-25 21:11:59', NULL),
(11, 'ESSAI', 'THURIER', 'Cyril', 45000, 'Centre', 'cyril@lapinet.fr', '81bc254fac24ec62ca7fd0465e6444237de8678e', NULL, NULL, NULL),
(12, 'THURIER', 'THURIER', 'Cyril', 45000, 'Centre', 'cyrilthurier@lapi.net', '2b7de26d3040af59bae87e85b21ad08c81ba2870', NULL, NULL, NULL),
(13, 'Jean', 'Aimard', 'Jean', 75004, 'Ile-de-France', 'jeanaimard@manger.ca', '97ffb18ddf0d56f94c19c2ae7e81575659215d0f', NULL, NULL, NULL),
(14, 'JeanJean', 'Aimard', 'Jean', 65762, 'Midi-Pyrenees', 'jeanaimard@manger.ca', '3a6da33014f5dcbf98bde9f0de4d5e84c9a8e340', NULL, NULL, NULL),
(15, 'Jean7855', 'Aimard', 'Jean', 45678, 'Centre', 'jeanaimard@manger.ca', 'b1954ad57c2517dff0af1e6e54de254ef6717223', NULL, NULL, NULL),
(16, 'JeanJean2', 'Aimard', 'Jean', 78642, 'Ile-de-France', 'jeanaimard@manger.ca', 'af36f172483c7132f557affe581d631efeeae008', NULL, NULL, NULL),
(17, 'JeanJean7', 'Aimard', 'Jean', 76545, 'Haute-Normandie', 'jeanaimard@manger.ca', '01600ef42f391e911babec93def8511fa27ea7c8', NULL, NULL, NULL),
(18, 'JeanJean56', 'Aimard', 'Jean', 45658, 'Centre', 'jeanaimard@manger.ca', 'cd18663511ac53fce463cebc39c3d44012a54e65', NULL, NULL, NULL),
(19, 'JeanJean12', 'Aimard', 'Jean', 45627, 'Centre', 'jeanaimard@manger.ca', 'cc77a02decf6ec18ffcb31d8667dee70520543c5', NULL, NULL, NULL),
(20, 'JeanJean453', 'Aimard', 'Jean', 44533, 'Pays-de-la-Loire', 'jeanaimard@manger.ca', 'fd01db68d8a9238fb465d9adf49cba20a7acc337', NULL, NULL, NULL),
(21, 'JeanJean82', 'Aimard', 'Jean', 58653, 'Bourgogne', 'jeanaimard@manger.ca', '6562c46a3cd4bdff4c842939dcf29d2b2f6db342', NULL, NULL, NULL),
(22, 'JeanJean789', 'Aimard', 'Jean', 47562, 'Aquitaine', 'jeanaimard@manger.ca', 'b7808cb8fe9fe0eeba523125c7692a5afee35ed2', NULL, NULL, NULL),
(23, 'JeanJean7869', 'Aimard', 'Jean', 85654, 'Pays-de-la-Loire', 'jeanaimard@manger.ca', '3c76fde14202fb7957bce0d6f983a1aa31c8a4fe', NULL, NULL, NULL),
(24, 'Lapi', 'Lapi', 'Pinpin', 45000, 'Centre', 'lapinCretin@hotmail.com', '2efe1ee2d45e7407e577fa4eec4122a6606fd3d4', NULL, NULL, NULL),
(25, 'ESSAI2', 'retertergd', 'jhgfjhgf', 78956, 'Ile-de-France', 'cyril@lapi.fr', '05224ae0bb6f6d9323634d8c14ef60ceeaeeef18', NULL, NULL, NULL),
(26, 'Julie', 'Philibert', 'Julie', 45510, 'Centre', 'philibertjulie@yahoo.fr', 'ce4100f3a88ad2d43be24b52a1eaa4d2e7dd14c5', '2013-03-25 17:38:17', '2013-03-25 17:11:17', NULL),
(27, 'dominique', 'Dom', 'Dom', 45000, 'Centre', 'dominique.payant@etu-univ.fr', 'b3c6fa2fa16f95bf5286bdd282ed361d6be516d8', '2013-03-26 07:40:11', '2013-03-26 07:18:31', NULL),
(28, 'Cyril2', 'THURIER', 'Cyril', 45000, 'Centre', 'cyril.thurier@etuuniv-orleans.fr', '6dc37e5f18f6b0e8b32c70f1748794fc8bc115d7', NULL, NULL, NULL),
(29, 'oiuyoeirt', 'dflgjkdhfl', 'jksdhfks', 78952, 'Ile-de-France', 'cyril.thurier@etuuniv-orleans.fr', 'a601f1245f34337b501f0c18641c56ed23be8655', NULL, NULL, NULL),
(30, 'Jojo', 'Jolelapin', 'Gudule', 45100, 'Centre', 'jessica.durand@univ-orleans.fr', 'f2e3907dd527808316e0b2eabef99cc1f87283cf', '2013-03-26 10:41:41', '2013-03-26 10:29:30', NULL),
(31, 'Dudule', 'cance', 'Pinpin', 45000, '', 'jessica.durand@univ-orleans.fr', 'f8d054e6d827a9fab7dcd677373cbd0d048a1ee5', NULL, NULL, NULL),
(32, 'Zozo', 'Zozo', 'zozo', 79845, 'Poitou-Charentes', 'lapin@lapi.net', '2e38aa7378505023c3fed30fe39272b20a68a1cb', NULL, NULL, NULL);

--
-- Contenu de la table `lapin_repondA`
--


--
-- Contenu de la table `lapin_tchat_conversation`
--

INSERT INTO `lapin_tchat_conversation` (`id_conversation`, `user1`, `session_1`, `user2`, `session_2`) VALUES
(1, 'Cyril', '2013-03-25 17:12:19', 'Julie', '2013-03-25 17:11:17'),
(2, 'Jojo', '2013-03-25 20:00:26', 'dominique', '2013-03-25 19:03:55');

--
-- Contenu de la table `lapin_tchat_message`
--

INSERT INTO `lapin_tchat_message` (`id_message`, `conversation`, `expediteur`, `destinataire`, `texte`, `date`) VALUES
(6, 2, 'Jojo', 'dominique', 'C''est Jess\r\nsi tu as ce message c''est que ça fonctionne :D\r\n', '2013-03-25 20:27:08'),
(5, 2, 'Jojo', 'dominique', 'Salut', '2013-03-25 20:22:16'),
(7, 2, 'Jojo', 'dominique', '', '2013-03-25 20:27:11'),
(8, 2, 'Jojo', 'dominique', 'sinon ... je parle toute seule^^', '2013-03-25 20:27:25'),
(9, 2, 'Jojo', 'dominique', 'Francine ?\r\n', '2013-03-25 21:16:48'),
(10, 2, 'Jojo', 'dominique', '(le francine c''est parce qu''il y avait un lapin co de ce nom...) je ne peux aps lui parler si je suis déjà en conversation avec toi\r\n', '2013-03-25 21:18:17');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
